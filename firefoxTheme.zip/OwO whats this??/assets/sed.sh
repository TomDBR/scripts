#!/bin/sh
sed -i \
         -e 's/#fcfcfc/rgb(0%,0%,0%)/g' \
         -e 's/#474747/rgb(100%,100%,100%)/g' \
    -e 's/#fcfcfc/rgb(50%,0%,0%)/g' \
     -e 's/#f2c6d3/rgb(0%,50%,0%)/g' \
     -e 's/#f7f7f7/rgb(50%,0%,50%)/g' \
     -e 's/#474747/rgb(0%,0%,50%)/g' \
	$@
